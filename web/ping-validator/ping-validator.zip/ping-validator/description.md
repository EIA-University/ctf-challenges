# Ping validator?

Encontramos un servicio sospechoso en uno de los servidores de la EIA, podras obtener la flag oculta en el?

# Hints

## 1

Hay un compnente con una vulnerabilidad conocida, esta dependencia se encuentra en el package.json

# Solucion

El reto es el siguente texto encodeado en el siguiente orden: Binario, Hexadecimal, Base64, Base32:

```
Ahora si, toma tu flag: UEIA{3nc0d1ng_15_4m4z1ng@U_Enc0d3rs12}
```

Para resolverlo, puede hacerse en cyberchef usando la receta de forma inversa

Base32, Base64, Hexadecimal y por ultimo Binario para volver al texto original

# Flag

UEIA{3nc0d1ng_15_4m4z1ng@U_Enc0d3rs12}
